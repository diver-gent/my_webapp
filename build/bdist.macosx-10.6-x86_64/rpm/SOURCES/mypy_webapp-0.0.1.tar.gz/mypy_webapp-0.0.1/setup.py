from distutils.core import setup

setup(
    name='mypy_webapp',
    version='0.0.1',
    packages=['mypy_webapp', 'mypy_webapp.tests'],
    url='https://github.com/diver-gent/my_webapp.git',
    license='',
    author='townsley',
    author_email='williamwtownsleyiii@gmail.com',
    description='Stoopid Sample Webapp'
)
